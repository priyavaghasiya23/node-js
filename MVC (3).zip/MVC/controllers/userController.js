const userModel = require('../model/userModel');

// Create User
// const createUser = async (req, res, next) => {
//     try {
//         const data = await userModel.create(req.body);
//         res.send(data); 
//     } catch (err) {
//         next(err);
//     }
// };

const createUser =  async(req, res,next) => {
    try{
        const data = await userModel.create(req.body);
        res.cookie("data",data.name);
        res.json({success: true,user:data});
    }catch(err){
        next(err);
    }
};


const Login = async (req, res, next) => {
    try {
        const { name, password } = req.body;
        const data = await userModel.findOne({name});

        if (!data){
             return res.send('Name not found');
        }
        if (data.password !== password){
            return res.send('Password does not match');
        }
        res.send('Logged in'); 
    } catch (err) {
        next(err);
    }
};

const getUser = (req,res)=>{
    const username = req.cookies.data;
    if(username){
        res.json({user});
    } else{
        res.json({error:'no user cookies set'});

    }

};


const LoginUi = (req, res) => {
    res.render('login');
};

module.exports = { createUser, getUser, Login, LoginUi };
