const isAuth = async (req, resiseBy, next) => {
    const { id } = req.cookies;
    if (id) {
        next();
    } else {
        res.redirect("/user/login");
    }
};

module.exports = isAuth;
