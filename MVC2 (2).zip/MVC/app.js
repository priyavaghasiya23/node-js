const express = require('express');
// const cookieParser = require('cookie-parser');
const path = require('path');
require('./config/db');
const userRoutes = require('./routes/userRoutes');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.get('/', (req, res) => res.render('home'));
app.use('/user', userRoutes);

app.listen(3005, () => 
  console.log('Server running on http://localhost:3005')
);