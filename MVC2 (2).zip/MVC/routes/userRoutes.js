const express = require("express");
const { createUser, getUser, Login, LoginUi } = require("../controllers/userController");
// const isAuth = require("../middleware/Auth");

const route = express.Router();

// CRUD Routes
route.post("/create", createUser);
route.get("/home", isAuth, getUser);
route.get("/login", LoginUi);
route.post("/login", Login);

module.exports = route;

