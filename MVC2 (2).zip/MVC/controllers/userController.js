const userModel = require('../model/userModel');

// Create User
const createUser = async (req, res, next) => {
    try {
        const data = await userModel.create(req.body);
        res.send(data); 
    } catch (err) {
        next(err);
    }
};

const getUser = (req, res) => {
    res.render('home', { user: null }); 
};


const Login = async (req, res, next) => {
    try {
        const { name, password } = req.body;
        const data = await userModel.findOne({ username: name });
        if (!data) return res.send('Name not found');
        if (data.password !== password) return res.send('Password does not match');
        res.send('Logged in'); 
    } catch (err) {
        next(err);
    }
};


const LoginUi = (req, res) => {
    res.render('login');
};

module.exports = { createUser, getUser, Login, LoginUi };
