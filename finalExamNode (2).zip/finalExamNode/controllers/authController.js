const User = require('../models/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const JWT_SECRET = 'supersecretkey'; // exam ke liye; real me .env use karo

const createToken = (user) => {
  return jwt.sign({ id: user._id, role: user.role, username: user.username }, JWT_SECRET, {
    expiresIn: '1d',
  });
};

exports.register = async (req, res) => {
  try {
    const { username, email, password } = req.body;
    // If userSchema pre-save hashes, we can just create
    await User.create({ username, email, password });
    res.redirect('/login');
  } catch (err) {
    console.error(err);
    res.send('Registration failed. Maybe user already exists.');
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.send('Invalid credentials');

    const matched = await bcrypt.compare(password, user.password);
    if (!matched) return res.send('Invalid credentials');

    const token = createToken(user);
    res.cookie('jwt', token, { httpOnly: true });
    res.redirect('/recipes');
  } catch (err) {
    console.error(err);
    res.send('Login error');
  }
};

exports.logout = (req, res) => {
  res.clearCookie('jwt');
  res.redirect('/login');
};
