const jwt = require('jsonwebtoken');
const JWT_SECRET = 'supersecretkey';

exports.requireAuth = (req, res, next) => {
  const token = req.cookies.jwt;
  if (!token) return res.redirect('/login');

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) return res.redirect('/login');
    req.user = decoded; // id, role, username
    next();
  });
};

exports.requireRole = (role) => {
  return (req, res, next) => {
    if (!req.user) return res.redirect('/login');
    if (req.user.role !== role) return res.status(403).send('Access denied');
    next();
  };
};
