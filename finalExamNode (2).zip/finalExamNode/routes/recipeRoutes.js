const express = require('express');
const router = express.Router();
const { requireAuth } = require('../Middleware/authMiddleware');
const Recipe = require('../models/Recipe');
const User = require('../models/User');

// All recipes (public)
router.get('/recipes', requireAuth, async (req, res) => {
  const recipes = await Recipe.find().populate('user', 'username');
  res.render('recipes', { recipes, user: req.user });
});

module.exports = router;
