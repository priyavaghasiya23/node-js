const Product = require('../models/Product');
const Category = require('../models/Category');
const Brand = require('../models/Brand');

// Show all products (with populated category & brand)
exports.getAllProducts = async (req, res) => {
  const products = await Product.find().populate('category').populate('brand');
  res.render('productList', { products });
};

// Show Add Form
exports.getAddProduct = async (req, res) => {
  const categories = await Category.find();
  const brands = await Brand.find();
  res.render('addProduct', { categories, brands });
};

// Add Product
exports.postAddProduct = async (req, res) => {
  const { name, price, category, brand, image } = req.body;

  const product = new Product({
    name,
    price,
    category,
    brand,
    image, // image URL
  });

  await product.save();
  res.redirect('/products');
};

// Show Edit Form
exports.getEditProduct = async (req, res) => {
  const product = await Product.findById(req.params.id);
  const categories = await Category.find();
  const brands = await Brand.find();
  res.render('editProduct', { product, categories, brands });
};

// Update Product
exports.postEditProduct = async (req, res) => {
  const { name, price, category, brand, image } = req.body;

  await Product.findByIdAndUpdate(req.params.id, {
    name,
    price,
    category,
    brand,
    image,
  });

  res.redirect('/products');
};

// Delete Product
exports.deleteProduct = async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.redirect('/products');
};
