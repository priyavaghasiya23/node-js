const User = require('../models/User');

// Create
exports.createUser = async (req, res) => {
    const { name, email, age } = req.body;
    const user = new User({ name, email, age });
    await user.save();
    res.json(user);
};

// Read All
exports.getUsers = async (req, res) => {
    const users = await User.find();
    res.json(users);
};

// Read Single
exports.getUser = async (req, res) => {
    const user = await User.findById(req.params.id);
    res.json(user);
};

// Update
exports.updateUser = async (req, res) => {
    const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(user);
};

// Delete
exports.deleteUser = async (req, res) => {
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'User deleted' });
};
