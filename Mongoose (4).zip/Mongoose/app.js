const express = require("express");
const db = require("./config/db");
const userModel = require("./model/userModel");
const multer=require("multer")
const path=require("path")

const app = express();

const methodOverride = require("method-override");


app.set("view engine", "ejs");
app.use(express.static("public"));


app.use("/upload",express.static(path.join(__dirname,"upload")))
app.use(express.urlencoded());
app.use(express.json());
app.use(methodOverride("_method"));


const storage=multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, 'upload/');
    },
    filename: function(req, file, cb) {
        cb(null, file.originalname);
    }
})

const upload = multer({ storage: storage }).single("image");



app.post("/insertData",upload, async (req, res) => {
    const { username,password}=req.body
    let image=""
    if(req.file){
        image=req.file.path
    }
    await userModel.create({
        username:username,
        password:password,
        image:image
        }).then((data)=>{
            console.log(data)
            res.redirect("/")
        }).catch((err)=>{
            console.log(err)
        })

    })


app.get("/", async (req, res) => {
    await userModel.find({}).then((data)=>{
        res.render("home",{data})
    }).catch((err)=>{
        console.log(err)
    })
});


// app.delete("/:id",async(req,res)=>{
//     const id=req.params.id;
//     console.log(id)
//     await userModel.findByIdAndDelete(id);
//     res.send("deleted");
// })

app.patch("/:id",async(req,res)=>{
    const id=req.params.id;
    const data=await userModel.findByIdAndUpdate(id,res.body)
    res.send(data); 
})

app.get("/deleteData",(req,res)=>{
    const userid=req.query.userid;
    adminModel.findById(userid).then((single)=>{
        if(single.image){
            fs.unlinkSync(single.image);

        }
        return adminModel.findByIdAndDelete(userid)
        
    }).then((data)=>{
        console.log("Data Successfully deleted");
        res .redirect("/");

    }).catch((err)=>{
        console.log(err);
    });
});

// app.get("/edit/:id",async(req,res)=>{
//     const userId=req.params.id;
//     try{
//         const user = await userModel.findById(userId);
//         res.render("edit",{user});
//         }catch(err){
//             console.log(err);
//             res.send("Error");
            
//     }
// });

app.listen(6789, () => {
    console.log("server connect");
});  
