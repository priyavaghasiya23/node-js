const userModel = require('../model/userModel');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const SECRET_KEY = 'jwt_secret_key';

const createUser = async (req, res, next) => {
    try {
        const { name, password } = req.body;

        // Check if user already exists
        const existing = await userModel.findOne({ name });
        if (existing) return res.send("User already exists");

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        const data = await userModel.create({ name, password: hashedPassword });

        res.json({ success: true, user: data });
    } catch (err) {
        next(err);
    }
};

const Login = async (req, res, next) => {
    try {
        const { name, password } = req.body;
        const data = await userModel.findOne({ name });

        if (!data) return res.send('Name not found');

        const isMatch = await bcrypt.compare(password, data.password);
        if (!isMatch) return res.send('Password does not match');

        // JWT token create
        const token = jwt.sign({ id: data._id, name: data.name }, SECRET_KEY, { expiresIn: '1h' });

        // Store token in cookie
        res.cookie("token", token, { httpOnly: true });
        res.send('Logged in with JWT');
    } catch (err) {
        next(err);
    }
};

const getUser = (req, res) => {
    const user = req.user; // from middleware

    
    if (user) {
        res.json({ user });
    } else {
        res.status(401).json({ error: 'Invalid token' });
    }
};

const LoginUi = (req, res) => {
    res.render('login');
};

module.exports = { createUser, getUser, Login, LoginUi };
