const mongoose = require("mongoose");

mongoose.connect("mongodb://127.0.0.1:27017/mvc", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});


const db = mongoose.connection;

db.on("connected", () => {
    console.log(" MongoDB Connected Successfully");
});

db.on("error", (err) => {
    console.log(" MongoDB Connection Error:", err);
});

module.exports = db;
